# start of script
print ("Hello world!") # English
print ("Hola Mundo!") # Spanish
print ("Bonjour le monde!") # French
print ("Hallo Welt") # German 
print ("Привет, мир") # Russian 
print ("Përshendetje Botë") # Albanian 
print ("Hola món") # Catalan 
print ("你好，世界") # Simplified Chinese 
print ("你好，世界") # Traditional Chinese 
print ("Hallo Wereld") # Dutch 
print ("Halo Dunia") # Indonesian 
print ("שלום עולם") # Hebrew 
print ("Ciao mondo") # Italian 
print ("Chào thế giới") # Vietnamese
print ("Helo Byd") # Welsh 
print ("Hej världen") # Swedish 
print ("こんにちは世界") # Japanese 
print ("ahoj svet") # Slovak
print ("Selam Dünya") # Turkish
print ("Olá Mundo") # Portugese
noMore = input("Please press [ENTER] key to quit") # end of program
'''
Please report accuracy
Non-english translations done with Google Translate
'''
'''
Hello world in 20 languages
feel free to correct and add in more languages if needed
Open-source project by @seanwallawalla
copyleft 2015-2019
'''
# end of script